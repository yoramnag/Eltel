package enums;

public enum Color {
	red, green, blue
}
