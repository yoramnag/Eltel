package enums;

public enum Shape {
	circle, square, triangle
}
