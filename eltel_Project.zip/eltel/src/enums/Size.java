package enums;

public enum Size {
	small, medium, large
}
